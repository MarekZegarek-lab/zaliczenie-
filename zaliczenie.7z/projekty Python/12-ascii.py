for i in range(ord('a'), ord('z')+1):
    print(chr(i), end=" ")
print()
for i in range(ord('A'), ord('Z')+1):
    print(chr(i), end=" ")
